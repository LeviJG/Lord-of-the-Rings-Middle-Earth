package net.blueskiez77.lord_of_the_rings__middle_earth.datagen;

import java.util.List;

import net.blueskiez77.lord_of_the_rings__middle_earth.common.block.LOTRDecorationBlocks;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.block.LOTRFoodBlocks;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRCombatItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRFoodItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRMaterialItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRMiscItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRStoryItems;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRToolItems;

import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.client.data.models.model.ItemModelUtils;
import net.minecraft.client.data.models.model.ModelTemplates;
import net.minecraft.client.renderer.item.EmptyModel;
import net.minecraft.client.renderer.item.properties.select.DisplayContext;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemDisplayContext;

/**
 * The items drawn as a single flat sprite of their own texture, the way
 * vanilla's ItemModelGenerators lists its flat and handheld items one by one.
 * Handheld is the tilted, in-the-hand pose tools and weapons use.
 *
 * <p>Items whose look needs more (bow pull stages, large in-hand models,
 * pikes, beds, chests) keep hand-written models under src/main/resources.
 */
final class LOTRFlatItemModels {

    private static final List<Item> FLAT = List.of(
            // LOTRCombatItems
            LOTRCombatItems.ANGMAR_BOOTS, LOTRCombatItems.ANGMAR_CHESTPLATE, LOTRCombatItems.ANGMAR_HELMET,
            LOTRCombatItems.ANGMAR_LEGGINGS, LOTRCombatItems.ANGMAR_WARG_ARMOR, LOTRCombatItems.ARNOR_BOOTS,
            LOTRCombatItems.ARNOR_CHESTPLATE, LOTRCombatItems.ARNOR_HELMET, LOTRCombatItems.ARNOR_LEGGINGS,
            LOTRCombatItems.BLACK_NUMENOREAN_BOOTS, LOTRCombatItems.BLACK_NUMENOREAN_CHESTPLATE, LOTRCombatItems.BLACK_NUMENOREAN_HELMET,
            LOTRCombatItems.BLACK_NUMENOREAN_LEGGINGS, LOTRCombatItems.BLACK_URUK_BOOTS, LOTRCombatItems.BLACK_URUK_CHESTPLATE,
            LOTRCombatItems.BLACK_URUK_HELMET, LOTRCombatItems.BLACK_URUK_LEGGINGS, LOTRCombatItems.BLACKROOT_VALE_BOOTS,
            LOTRCombatItems.BLACKROOT_VALE_CHESTPLATE, LOTRCombatItems.BLACKROOT_VALE_HELMET, LOTRCombatItems.BLACKROOT_VALE_LEGGINGS,
            LOTRCombatItems.BLUE_DWARVEN_BOAR_ARMOR, LOTRCombatItems.BLUE_DWARVEN_BOOTS, LOTRCombatItems.BLUE_DWARVEN_CHESTPLATE,
            LOTRCombatItems.BLUE_DWARVEN_HELMET, LOTRCombatItems.BLUE_DWARVEN_LEGGINGS, LOTRCombatItems.BONE_BOOTS,
            LOTRCombatItems.BONE_CHESTPLATE, LOTRCombatItems.BONE_HELMET, LOTRCombatItems.BONE_LEGGINGS,
            LOTRCombatItems.BRONZE_BOOTS, LOTRCombatItems.BRONZE_CHESTPLATE, LOTRCombatItems.BRONZE_HELMET,
            LOTRCombatItems.BRONZE_LEGGINGS, LOTRCombatItems.COAST_SOUTHRON_BOOTS, LOTRCombatItems.COAST_SOUTHRON_CHESTPLATE,
            LOTRCombatItems.COAST_SOUTHRON_HELMET, LOTRCombatItems.COAST_SOUTHRON_HORSE_ARMOR, LOTRCombatItems.COAST_SOUTHRON_LEGGINGS,
            LOTRCombatItems.COMMAND_HORN, LOTRCombatItems.CORSAIR_BOOTS, LOTRCombatItems.CORSAIR_CHESTPLATE,
            LOTRCombatItems.CORSAIR_HELMET, LOTRCombatItems.CORSAIR_LEGGINGS, LOTRCombatItems.CROSSBOW_BOLT,
            LOTRCombatItems.DALE_BOOTS, LOTRCombatItems.DALE_CHESTPLATE, LOTRCombatItems.DALE_GAMBESON,
            LOTRCombatItems.DALE_HELMET, LOTRCombatItems.DALE_HORSE_ARMOR, LOTRCombatItems.DALE_LEGGINGS,
            LOTRCombatItems.DOL_AMROTH_BOOTS, LOTRCombatItems.DOL_AMROTH_CHAPS, LOTRCombatItems.DOL_AMROTH_CHESTPLATE,
            LOTRCombatItems.DOL_AMROTH_GAMBESON, LOTRCombatItems.DOL_AMROTH_HELMET, LOTRCombatItems.DOL_AMROTH_HORSE_ARMOR,
            LOTRCombatItems.DOL_AMROTH_LEGGINGS, LOTRCombatItems.DOL_GULDUR_BOOTS, LOTRCombatItems.DOL_GULDUR_CHESTPLATE,
            LOTRCombatItems.DOL_GULDUR_HELMET, LOTRCombatItems.DOL_GULDUR_LEGGINGS, LOTRCombatItems.DORWINION_BOOTS,
            LOTRCombatItems.DORWINION_CHESTPLATE, LOTRCombatItems.DORWINION_ELVEN_BOOTS, LOTRCombatItems.DORWINION_ELVEN_CHESTPLATE,
            LOTRCombatItems.DORWINION_ELVEN_HELMET, LOTRCombatItems.DORWINION_ELVEN_LEGGINGS, LOTRCombatItems.DORWINION_HELMET,
            LOTRCombatItems.DORWINION_LEGGINGS, LOTRCombatItems.DUNLENDING_BOOTS, LOTRCombatItems.DUNLENDING_CHESTPLATE,
            LOTRCombatItems.DUNLENDING_HELMET, LOTRCombatItems.DUNLENDING_LEGGINGS, LOTRCombatItems.DWARVEN_BOAR_ARMOR,
            LOTRCombatItems.DWARVEN_BOOTS, LOTRCombatItems.DWARVEN_CHESTPLATE, LOTRCombatItems.DWARVEN_HELMET,
            LOTRCombatItems.DWARVEN_LEGGINGS, LOTRCombatItems.FUR_BOOTS, LOTRCombatItems.FUR_HAT,
            LOTRCombatItems.FUR_LEGGINGS, LOTRCombatItems.FUR_TUNIC, LOTRCombatItems.GALADHRIM_BOOTS,
            LOTRCombatItems.GALADHRIM_CHESTPLATE, LOTRCombatItems.GALADHRIM_CLOAK_BOOTS, LOTRCombatItems.GALADHRIM_CLOAK_HOOD,
            LOTRCombatItems.GALADHRIM_CLOAK_LEGGINGS, LOTRCombatItems.GALADHRIM_CLOAK_TUNIC, LOTRCombatItems.GALADHRIM_HELMET,
            LOTRCombatItems.GALADHRIM_HORSE_ARMOR, LOTRCombatItems.GALADHRIM_LEGGINGS, LOTRCombatItems.GALVORN_BOOTS,
            LOTRCombatItems.GALVORN_CHESTPLATE, LOTRCombatItems.GALVORN_HELMET, LOTRCombatItems.GALVORN_LEGGINGS,
            LOTRCombatItems.GEMSBOK_HIDE_BOOTS, LOTRCombatItems.GEMSBOK_HIDE_CHESTPLATE, LOTRCombatItems.GEMSBOK_HIDE_HELMET,
            LOTRCombatItems.GEMSBOK_HIDE_LEGGINGS, LOTRCombatItems.GOLD_TRIMMED_DWARVEN_BOOTS, LOTRCombatItems.GOLD_TRIMMED_DWARVEN_CHESTPLATE,
            LOTRCombatItems.GOLD_TRIMMED_DWARVEN_HELMET, LOTRCombatItems.GOLD_TRIMMED_DWARVEN_LEGGINGS, LOTRCombatItems.GOLDEN_RHUNIC_BOOTS,
            LOTRCombatItems.GOLDEN_RHUNIC_CHESTPLATE, LOTRCombatItems.GOLDEN_RHUNIC_HELMET, LOTRCombatItems.GOLDEN_RHUNIC_LEGGINGS,
            LOTRCombatItems.GOLDEN_TAURETHRIM_BOOTS, LOTRCombatItems.GOLDEN_TAURETHRIM_CHESTPLATE, LOTRCombatItems.GOLDEN_TAURETHRIM_HELMET,
            LOTRCombatItems.GOLDEN_TAURETHRIM_LEGGINGS, LOTRCombatItems.GONDOLIN_BOOTS, LOTRCombatItems.GONDOLIN_CHESTPLATE,
            LOTRCombatItems.GONDOLIN_HELMET, LOTRCombatItems.GONDOLIN_LEGGINGS, LOTRCombatItems.GONDOR_BOOTS,
            LOTRCombatItems.GONDOR_CHESTPLATE, LOTRCombatItems.GONDOR_GAMBESON, LOTRCombatItems.GONDOR_HELMET,
            LOTRCombatItems.GONDOR_HORSE_ARMOR, LOTRCombatItems.GONDOR_LEGGINGS, LOTRCombatItems.GONDOR_WINGED_HELMET,
            LOTRCombatItems.GULFEN_BOOTS, LOTRCombatItems.GULFEN_CHESTPLATE, LOTRCombatItems.GULFEN_HELMET,
            LOTRCombatItems.GULFEN_LEGGINGS, LOTRCombatItems.GUNDABAD_URUK_BOOTS, LOTRCombatItems.GUNDABAD_URUK_CHESTPLATE,
            LOTRCombatItems.GUNDABAD_URUK_HELMET, LOTRCombatItems.GUNDABAD_URUK_LEGGINGS, LOTRCombatItems.HALF_TROLL_BOOTS,
            LOTRCombatItems.HALF_TROLL_CHESTPLATE, LOTRCombatItems.HALF_TROLL_HELMET, LOTRCombatItems.HALF_TROLL_LEGGINGS,
            LOTRCombatItems.HALF_TROLL_RHINO_ARMOR, LOTRCombatItems.HARNENNOR_BOOTS, LOTRCombatItems.HARNENNOR_CHESTPLATE,
            LOTRCombatItems.HARNENNOR_HELMET, LOTRCombatItems.HARNENNOR_LEGGINGS, LOTRCombatItems.ISENGARD_WARG_ARMOR,
            LOTRCombatItems.ITHILIEN_RANGER_BOOTS, LOTRCombatItems.ITHILIEN_RANGER_HOOD, LOTRCombatItems.ITHILIEN_RANGER_LEGGINGS,
            LOTRCombatItems.ITHILIEN_RANGER_TUNIC, LOTRCombatItems.LAMEDON_BOOTS, LOTRCombatItems.LAMEDON_CHESTPLATE,
            LOTRCombatItems.LAMEDON_HELMET, LOTRCombatItems.LAMEDON_HORSE_ARMOR, LOTRCombatItems.LAMEDON_JACKET,
            LOTRCombatItems.LAMEDON_LEGGINGS, LOTRCombatItems.LEBENNIN_GAMBESON, LOTRCombatItems.LINDON_BOOTS,
            LOTRCombatItems.LINDON_CHESTPLATE, LOTRCombatItems.LINDON_HELMET, LOTRCombatItems.LINDON_HORSE_ARMOR,
            LOTRCombatItems.LINDON_LEGGINGS, LOTRCombatItems.LOSSARNACH_BOOTS, LOTRCombatItems.LOSSARNACH_CHESTPLATE,
            LOTRCombatItems.LOSSARNACH_HELMET, LOTRCombatItems.LOSSARNACH_LEGGINGS, LOTRCombatItems.MITHRIL_BOOTS,
            LOTRCombatItems.MITHRIL_CHESTPLATE, LOTRCombatItems.MITHRIL_HELMET, LOTRCombatItems.MITHRIL_HORSE_ARMOR,
            LOTRCombatItems.MITHRIL_LEGGINGS, LOTRCombatItems.MITHRIL_TRIMMED_DWARVEN_BOOTS, LOTRCombatItems.MITHRIL_TRIMMED_DWARVEN_CHESTPLATE,
            LOTRCombatItems.MITHRIL_TRIMMED_DWARVEN_HELMET, LOTRCombatItems.MITHRIL_TRIMMED_DWARVEN_LEGGINGS, LOTRCombatItems.MORDOR_BOOTS,
            LOTRCombatItems.MORDOR_CHESTPLATE, LOTRCombatItems.MORDOR_HELMET, LOTRCombatItems.MORDOR_LEGGINGS,
            LOTRCombatItems.MORDOR_WARG_ARMOR, LOTRCombatItems.MORGUL_BOOTS, LOTRCombatItems.MORGUL_CHESTPLATE,
            LOTRCombatItems.MORGUL_HELMET, LOTRCombatItems.MORGUL_HORSE_ARMOR, LOTRCombatItems.MORGUL_LEGGINGS,
            LOTRCombatItems.MORWAITH_BOOTS, LOTRCombatItems.MORWAITH_CHESTPLATE, LOTRCombatItems.MORWAITH_CHIEFTAIN_BOOTS,
            LOTRCombatItems.MORWAITH_CHIEFTAIN_CHESTPLATE, LOTRCombatItems.MORWAITH_CHIEFTAIN_HELMET, LOTRCombatItems.MORWAITH_CHIEFTAIN_LEGGINGS,
            LOTRCombatItems.MORWAITH_HELMET, LOTRCombatItems.MORWAITH_LEGGINGS, LOTRCombatItems.NOMAD_CAP,
            LOTRCombatItems.NOMAD_LEGGINGS, LOTRCombatItems.NOMAD_SHOES, LOTRCombatItems.NOMAD_TUNIC,
            LOTRCombatItems.PEBBLE, LOTRCombatItems.PELARGIR_BOOTS, LOTRCombatItems.PELARGIR_CHESTPLATE,
            LOTRCombatItems.PELARGIR_HELMET, LOTRCombatItems.PELARGIR_LEGGINGS, LOTRCombatItems.PINNATH_GELIN_BOOTS,
            LOTRCombatItems.PINNATH_GELIN_CHESTPLATE, LOTRCombatItems.PINNATH_GELIN_HELMET, LOTRCombatItems.PINNATH_GELIN_LEGGINGS,
            LOTRCombatItems.POISONED_ARROW, LOTRCombatItems.POISONED_CROSSBOW_BOLT, LOTRCombatItems.POISONED_TAURETHRIM_DART,
            LOTRCombatItems.RANGER_BOOTS, LOTRCombatItems.RANGER_HOOD, LOTRCombatItems.RANGER_LEGGINGS,
            LOTRCombatItems.RANGER_TUNIC, LOTRCombatItems.RHUNIC_BOOTS, LOTRCombatItems.RHUNIC_CHESTPLATE,
            LOTRCombatItems.RHUNIC_FIRE_POT, LOTRCombatItems.RHUNIC_HELMET, LOTRCombatItems.RHUNIC_HORSE_ARMOR,
            LOTRCombatItems.RHUNIC_LEGGINGS, LOTRCombatItems.RHUNIC_WARLORD_HELMET, LOTRCombatItems.RIVENDELL_BOOTS,
            LOTRCombatItems.RIVENDELL_CHESTPLATE, LOTRCombatItems.RIVENDELL_HELMET, LOTRCombatItems.RIVENDELL_HORSE_ARMOR,
            LOTRCombatItems.RIVENDELL_LEGGINGS, LOTRCombatItems.ROHIRRIC_BOOTS, LOTRCombatItems.ROHIRRIC_COIF,
            LOTRCombatItems.ROHIRRIC_HAUBERK, LOTRCombatItems.ROHIRRIC_HORSE_ARMOR, LOTRCombatItems.ROHIRRIC_LEGGINGS,
            LOTRCombatItems.ROHIRRIC_MARSHAL_BOOTS, LOTRCombatItems.ROHIRRIC_MARSHAL_CHESTPLATE, LOTRCombatItems.ROHIRRIC_MARSHAL_HELMET,
            LOTRCombatItems.ROHIRRIC_MARSHAL_LEGGINGS, LOTRCombatItems.SILVER_TRIMMED_DWARVEN_BOOTS, LOTRCombatItems.SILVER_TRIMMED_DWARVEN_CHESTPLATE,
            LOTRCombatItems.SILVER_TRIMMED_DWARVEN_HELMET, LOTRCombatItems.SILVER_TRIMMED_DWARVEN_LEGGINGS, LOTRCombatItems.SOUTHRON_CHAMPION_HELMET,
            LOTRCombatItems.TAURETHRIM_BOOTS, LOTRCombatItems.TAURETHRIM_CHESTPLATE, LOTRCombatItems.TAURETHRIM_CHIEFTAIN_HELMET,
            LOTRCombatItems.TAURETHRIM_DART, LOTRCombatItems.TAURETHRIM_HELMET, LOTRCombatItems.TAURETHRIM_LEGGINGS,
            LOTRCombatItems.UMBARIC_BOOTS, LOTRCombatItems.UMBARIC_CHESTPLATE, LOTRCombatItems.UMBARIC_HELMET,
            LOTRCombatItems.UMBARIC_HORSE_ARMOR, LOTRCombatItems.UMBARIC_LEGGINGS, LOTRCombatItems.URUK_BERSERKER_HELMET,
            LOTRCombatItems.URUK_BOOTS, LOTRCombatItems.URUK_CHESTPLATE, LOTRCombatItems.URUK_HELMET,
            LOTRCombatItems.URUK_LEGGINGS, LOTRCombatItems.UTUMNO_BOOTS, LOTRCombatItems.UTUMNO_CHESTPLATE,
            LOTRCombatItems.UTUMNO_HELMET, LOTRCombatItems.UTUMNO_LEGGINGS, LOTRCombatItems.WOOD_ELVEN_BOOTS,
            LOTRCombatItems.WOOD_ELVEN_CHESTPLATE, LOTRCombatItems.WOOD_ELVEN_ELK_ARMOR, LOTRCombatItems.WOOD_ELVEN_HELMET,
            LOTRCombatItems.WOOD_ELVEN_LEGGINGS, LOTRCombatItems.WOOD_ELVEN_SCOUT_BOOTS, LOTRCombatItems.WOOD_ELVEN_SCOUT_HOOD,
            LOTRCombatItems.WOOD_ELVEN_SCOUT_LEGGINGS, LOTRCombatItems.WOOD_ELVEN_SCOUT_TUNIC,
            // LOTRDecorationBlocks
            LOTRDecorationBlocks.ANGMAR_BANNER.asItem(), LOTRDecorationBlocks.ANORIEN_BANNER.asItem(), LOTRDecorationBlocks.BLACK_URUK_BANNER.asItem(),
            LOTRDecorationBlocks.BLACKROOT_VALE_BANNER.asItem(), LOTRDecorationBlocks.BLUE_MOUNTAINS_BANNER.asItem(), LOTRDecorationBlocks.BREE_BANNER.asItem(),
            LOTRDecorationBlocks.CORN_STALK.asItem(), LOTRDecorationBlocks.DALE_BANNER.asItem(), LOTRDecorationBlocks.DOL_AMROTH_BANNER.asItem(),
            LOTRDecorationBlocks.DOL_GULDUR_BANNER.asItem(), LOTRDecorationBlocks.DORWINION_BANNER.asItem(), LOTRDecorationBlocks.DRIED_REEDS.asItem(),
            LOTRDecorationBlocks.DUNLAND_BANNER.asItem(), LOTRDecorationBlocks.DURIN_BANNER.asItem(), LOTRDecorationBlocks.ESGAROTH_BANNER.asItem(),
            LOTRDecorationBlocks.GONDOR_BANNER.asItem(), LOTRDecorationBlocks.GONDOR_STEWARD_BANNER.asItem(), LOTRDecorationBlocks.GUNDABAD_BANNER.asItem(),
            LOTRDecorationBlocks.HALF_TROLL_BANNER.asItem(), LOTRDecorationBlocks.HARAD_GULF_BANNER.asItem(), LOTRDecorationBlocks.HARAD_NOMAD_BANNER.asItem(),
            LOTRDecorationBlocks.HIGH_ELF_BANNER.asItem(), LOTRDecorationBlocks.HITHLAIN_LADDER.asItem(), LOTRDecorationBlocks.HOBBIT_BANNER.asItem(),
            LOTRDecorationBlocks.ISENGARD_BANNER.asItem(), LOTRDecorationBlocks.ITHILIEN_BANNER.asItem(), LOTRDecorationBlocks.LAMEDON_BANNER.asItem(),
            LOTRDecorationBlocks.LEBENNIN_BANNER.asItem(), LOTRDecorationBlocks.LOSSARNACH_BANNER.asItem(), LOTRDecorationBlocks.LOTHLORIEN_BANNER.asItem(),
            LOTRDecorationBlocks.MINAS_MORGUL_BANNER.asItem(), LOTRDecorationBlocks.MIRKWOOD_BANNER.asItem(), LOTRDecorationBlocks.MORDOR_BANNER.asItem(),
            LOTRDecorationBlocks.MOREDAIN_BANNER.asItem(), LOTRDecorationBlocks.NAN_UNGOL_BANNER.asItem(), LOTRDecorationBlocks.NEAR_HARAD_BANNER.asItem(),
            LOTRDecorationBlocks.PELARGIR_BANNER.asItem(), LOTRDecorationBlocks.PINNATH_GELIN_BANNER.asItem(), LOTRDecorationBlocks.RANGER_BANNER.asItem(),
            LOTRDecorationBlocks.REEDS.asItem(), LOTRDecorationBlocks.RHUDAUR_BANNER.asItem(), LOTRDecorationBlocks.RHUN_BANNER.asItem(),
            LOTRDecorationBlocks.RIVENDELL_BANNER.asItem(), LOTRDecorationBlocks.ROHAN_BANNER.asItem(), LOTRDecorationBlocks.TAUREDAIN_BANNER.asItem(),
            LOTRDecorationBlocks.UMBAR_BANNER.asItem(),
            // LOTRFoodBlocks
            LOTRFoodBlocks.APPLE_CRUMBLE.asItem(), LOTRFoodBlocks.BANANA_CAKE.asItem(), LOTRFoodBlocks.BERRY_PIE.asItem(),
            LOTRFoodBlocks.CHERRY_PIE.asItem(), LOTRFoodBlocks.DALISH_PASTRY.asItem(), LOTRFoodBlocks.LEMON_CAKE.asItem(),
            // LOTRFoodItems
            LOTRFoodItems.LETTUCE,
            LOTRFoodItems.ALE_HORN, LOTRFoodItems.ALMOND, LOTRFoodItems.BANANA,
            LOTRFoodItems.BANANA_BREAD, LOTRFoodItems.BLACKBERRIES, LOTRFoodItems.BLUEBERRIES,
            LOTRFoodItems.CERAMIC_MUG, LOTRFoodItems.CHERRIES, LOTRFoodItems.CHOCOLATE_MARCHPANE,
            LOTRFoodItems.CLAY_MUG, LOTRFoodItems.CLAY_PLATE, LOTRFoodItems.COOKED_CAMEL,
            LOTRFoodItems.COOKED_CORN, LOTRFoodItems.COOKED_LION, LOTRFoodItems.COOKED_MUTTON,
            LOTRFoodItems.COOKED_RHINO, LOTRFoodItems.COOKED_VENISON, LOTRFoodItems.COOKED_ZEBRA,
            LOTRFoodItems.COPPER_GOBLET, LOTRFoodItems.CORN, LOTRFoodItems.CORN_BREAD,
            LOTRFoodItems.CRAM, LOTRFoodItems.CRANBERRIES, LOTRFoodItems.DATE,
            LOTRFoodItems.ELDERBERRIES, LOTRFoodItems.GAMMON, LOTRFoodItems.GOLDEN_ALE_HORN,
            LOTRFoodItems.GOLDEN_GOBLET, LOTRFoodItems.GREEN_APPLE, LOTRFoodItems.GREEN_GRAPES,
            LOTRFoodItems.HOBBIT_PANCAKE, LOTRFoodItems.HOBBIT_PANCAKE_WITH_MAPLE_SYRUP, LOTRFoodItems.LEEK_SOUP,
            LOTRFoodItems.LEMBAS, LOTRFoodItems.LEMON, LOTRFoodItems.LIME,
            LOTRFoodItems.MAGGOTY_BREAD, LOTRFoodItems.MALLORN_NUT, LOTRFoodItems.MAN_FLESH,
            LOTRFoodItems.MANGO, LOTRFoodItems.MAPLE_SYRUP, LOTRFoodItems.MARCHPANE,
            LOTRFoodItems.MELON_SOUP, LOTRFoodItems.MUG, LOTRFoodItems.MUSHROOM_PIE,
            LOTRFoodItems.OLIVE_BREAD, LOTRFoodItems.OLIVES, LOTRFoodItems.ORANGE,
            LOTRFoodItems.PEAR, LOTRFoodItems.PLUM, LOTRFoodItems.POMEGRANATE,
            LOTRFoodItems.RABBIT_STEW, LOTRFoodItems.RAISINS, LOTRFoodItems.RASPBERRIES,
            LOTRFoodItems.RAW_CAMEL, LOTRFoodItems.RAW_LION, LOTRFoodItems.RAW_MUTTON,
            LOTRFoodItems.RAW_RHINO, LOTRFoodItems.RAW_VENISON, LOTRFoodItems.RAW_ZEBRA,
            LOTRFoodItems.RED_GRAPES, LOTRFoodItems.ROAST_CHESTNUT, LOTRFoodItems.ROAST_TURNIP,
            LOTRFoodItems.ROAST_YAM, LOTRFoodItems.SALT, LOTRFoodItems.SILVER_GOBLET,
            LOTRFoodItems.SKULL_CUP, LOTRFoodItems.SUSPICIOUS_MEAT, LOTRFoodItems.TOROG_STEW,
            LOTRFoodItems.WATERSKIN, LOTRFoodItems.WILDBERRIES, LOTRFoodItems.WINE_GLASS,
            LOTRFoodItems.WOODEN_CUP,
            // LOTRItems
            LOTRItems.KEBAB, LOTRItems.MALLORN_ENT_TROPHY, LOTRItems.MOUNTAIN_TROLL_CHIEFTAIN_TROPHY,
            LOTRItems.TROLL_STATUE,
            // LOTRMaterialItems
            LOTRMaterialItems.AMBER, LOTRMaterialItems.AMETHYST, LOTRMaterialItems.BLACK_URUK_STEEL_INGOT,
            LOTRMaterialItems.BLUE_DWARVEN_STEEL_INGOT, LOTRMaterialItems.BLUEBELL_BLUE, LOTRMaterialItems.BOOK_OF_TRUE_SILVER,
            LOTRMaterialItems.BRONZE_INGOT, LOTRMaterialItems.BROWN_DYE, LOTRMaterialItems.CHARCOAL_DUST,
            LOTRMaterialItems.CHILL_OF_DAEDELOS, LOTRMaterialItems.CLOVER_GREEN, LOTRMaterialItems.CORAL,
            LOTRMaterialItems.DIAMOND, LOTRMaterialItems.DURNOR, LOTRMaterialItems.DWARVEN_STEEL_INGOT,
            LOTRMaterialItems.EDHELVIR, LOTRMaterialItems.ELVEN_STEEL_INGOT, LOTRMaterialItems.EMERALD,
            LOTRMaterialItems.FLAME_OF_UDUN, LOTRMaterialItems.FLAX, LOTRMaterialItems.FUR,
            LOTRMaterialItems.GALVORN_INGOT, LOTRMaterialItems.GATE_GEARS, LOTRMaterialItems.GEMSBOK_HIDE,
            LOTRMaterialItems.GEMSBOK_HORN, LOTRMaterialItems.GILDED_IRON_INGOT, LOTRMaterialItems.GREEN_GRAPE_SEEDS,
            LOTRMaterialItems.GULDURIL, LOTRMaterialItems.HEADHUNTERS_TROPHY, LOTRMaterialItems.HITHLAIN,
            LOTRMaterialItems.HORN, LOTRMaterialItems.ITHILDIN, LOTRMaterialItems.KINE_OF_ARAW_HORN,
            LOTRMaterialItems.LION_FUR, LOTRMaterialItems.MITHRIL_MAIL, LOTRMaterialItems.MITHRIL_NUGGET,
            LOTRMaterialItems.MORGUL_STEEL_INGOT, LOTRMaterialItems.NITER, LOTRMaterialItems.OBSIDIAN_SHARD,
            LOTRMaterialItems.OPAL, LOTRMaterialItems.ORC_STEEL_INGOT, LOTRMaterialItems.PEARL,
            LOTRMaterialItems.PIPEWEED_LEAF, LOTRMaterialItems.RED_CLAY_BALL, LOTRMaterialItems.RED_GRAPE_SEEDS,
            LOTRMaterialItems.RHINO_HORN, LOTRMaterialItems.RUBY, LOTRMaterialItems.SAPPHIRE,
            LOTRMaterialItems.SILVER_INGOT, LOTRMaterialItems.SILVER_NUGGET, LOTRMaterialItems.SMITHS_SCROLL,
            LOTRMaterialItems.SULFUR, LOTRMaterialItems.SWAN_FEATHER, LOTRMaterialItems.TIN_INGOT,
            LOTRMaterialItems.TOPAZ, LOTRMaterialItems.URUK_STEEL_INGOT, LOTRMaterialItems.WHITE_DYE,
            LOTRMaterialItems.YELLOW_DYE,
            // LOTRMiscItems
            LOTRMiscItems.ANCIENT_ARMOR_PLATE, LOTRMiscItems.ANCIENT_BOOTS, LOTRMiscItems.ANCIENT_CHESTPLATE,
            LOTRMiscItems.ANCIENT_DAGGER, LOTRMiscItems.ANCIENT_HELMET, LOTRMiscItems.ANCIENT_LEGGINGS,
            LOTRMiscItems.ANCIENT_SWORD, LOTRMiscItems.ANCIENT_SWORD_BLADE, LOTRMiscItems.ANCIENT_SWORD_HILT,
            LOTRMiscItems.ANCIENT_SWORD_TIP, LOTRMiscItems.BLUE_DALISH_CRACKER, LOTRMiscItems.BOTTLE_OF_POISON,
            LOTRMiscItems.CONKER, LOTRMiscItems.DWARVEN_MARRIAGE_RING, LOTRMiscItems.EXPLODING_TERMITE,
            LOTRMiscItems.GOLD_DALISH_CRACKER, LOTRMiscItems.GOLD_RING, LOTRMiscItems.GREEN_DALISH_CRACKER,
            LOTRMiscItems.HOBBIT_MARRIAGE_RING, LOTRMiscItems.ICE_KEY_HANDLE, LOTRMiscItems.ICE_KEY_PIN,
            LOTRMiscItems.ICE_KEY_SHAFT, LOTRMiscItems.KEY_OF_ICE, LOTRMiscItems.KEY_OF_OBSIDIAN,
            LOTRMiscItems.MECHANISM, LOTRMiscItems.MITHRIL_RING, LOTRMiscItems.MYSTERY_WEB,
            LOTRMiscItems.OBSIDIAN_KEY_HANDLE, LOTRMiscItems.OBSIDIAN_KEY_PIN, LOTRMiscItems.OBSIDIAN_KEY_SHAFT,
            LOTRMiscItems.RED_BOOK, LOTRMiscItems.NPC_RESPAWNER, LOTRMiscItems.RED_DALISH_CRACKER, LOTRMiscItems.SILVER_COIN,
            LOTRMiscItems.SILVER_COIN_PILE, LOTRMiscItems.SILVER_COIN_STACK, LOTRMiscItems.SILVER_DALISH_CRACKER,
            LOTRMiscItems.SILVER_RING, LOTRMiscItems.SMOKING_PIPE, LOTRMiscItems.TAURETHRIM_AMULET);

    // The elven daggers and Sting are not here: their models and items/*.json
    // are hand-written in resources, for the glow near orcs
    // (LOTRElvenBladeItemModel), which datagen has no way to write.
    private static final List<Item> HANDHELD = List.of(
            // LOTRCombatItems
            LOTRCombatItems.ANGMAR_BATTLEAXE, LOTRCombatItems.ANGMAR_DAGGER, LOTRCombatItems.ANGMAR_WARHAMMER,
            LOTRCombatItems.ARNOR_DAGGER, LOTRCombatItems.BARROW_BLADE, LOTRCombatItems.BLACK_NUMENOREAN_DAGGER,
            LOTRCombatItems.BLACK_NUMENOREAN_MACE, LOTRCombatItems.BLACK_URUK_DAGGER, LOTRCombatItems.BLACKSMITH_HAMMER,
            LOTRCombatItems.BLUE_DWARVEN_BATTLEAXE, LOTRCombatItems.BLUE_DWARVEN_DAGGER, LOTRCombatItems.BLUE_DWARVEN_SWORD,
            LOTRCombatItems.BLUE_DWARVEN_THROWING_AXE, LOTRCombatItems.BLUE_DWARVEN_WARHAMMER, LOTRCombatItems.BRONZE_BATTLEAXE,
            LOTRCombatItems.BRONZE_DAGGER, LOTRCombatItems.BRONZE_SWORD, LOTRCombatItems.BRONZE_THROWING_AXE,
            LOTRCombatItems.CORSAIR_BATTLEAXE, LOTRCombatItems.CORSAIR_DAGGER, LOTRCombatItems.CORSAIR_EKET,
            LOTRCombatItems.DALE_DAGGER, LOTRCombatItems.DOL_AMROTH_DAGGER, LOTRCombatItems.DOL_GULDUR_BATTLEAXE,
            LOTRCombatItems.DOL_GULDUR_DAGGER, LOTRCombatItems.DWARVEN_BATTLEAXE,
            LOTRCombatItems.DWARVEN_DAGGER, LOTRCombatItems.DWARVEN_SWORD, LOTRCombatItems.DWARVEN_THROWING_AXE,
            LOTRCombatItems.DWARVEN_WARHAMMER, LOTRCombatItems.GONDOR_DAGGER,
            LOTRCombatItems.GONDOR_WARHAMMER, LOTRCombatItems.GUNDABAD_URUK_DAGGER, LOTRCombatItems.HALF_TROLL_DAGGER,
            LOTRCombatItems.HARADRIC_DAGGER, LOTRCombatItems.IRON_BATTLEAXE, LOTRCombatItems.IRON_DAGGER,
            LOTRCombatItems.IRON_THROWING_AXE, LOTRCombatItems.LOSSARNACH_THROWING_AXE,
            LOTRCombatItems.MALLORN_SWORD, LOTRCombatItems.MITHRIL_BATTLEAXE, LOTRCombatItems.MITHRIL_DAGGER,
            LOTRCombatItems.MITHRIL_WARHAMMER, LOTRCombatItems.MORDOR_BATTLEAXE, LOTRCombatItems.MORDOR_DAGGER,
            LOTRCombatItems.MORDOR_WARHAMMER, LOTRCombatItems.MORGUL_BLADE, LOTRCombatItems.MORWAITH_BATTLEAXE,
            LOTRCombatItems.MORWAITH_DAGGER, LOTRCombatItems.OLD_HARADRIC_SACRIFICIAL_DAGGER, LOTRCombatItems.ORC_SKULL_STAFF,
            LOTRCombatItems.PELARGIR_EKET, LOTRCombatItems.POISONED_ANGMAR_DAGGER, LOTRCombatItems.POISONED_ARNOR_DAGGER,
            LOTRCombatItems.POISONED_BARROW_BLADE, LOTRCombatItems.POISONED_BLACK_NUMENOREAN_DAGGER, LOTRCombatItems.POISONED_BLACK_URUK_DAGGER,
            LOTRCombatItems.POISONED_BLUE_DWARVEN_DAGGER, LOTRCombatItems.POISONED_BRONZE_DAGGER, LOTRCombatItems.POISONED_CORSAIR_DAGGER,
            LOTRCombatItems.POISONED_DALE_DAGGER, LOTRCombatItems.POISONED_DOL_AMROTH_DAGGER, LOTRCombatItems.POISONED_DOL_GULDUR_DAGGER,
            LOTRCombatItems.POISONED_DWARVEN_DAGGER, LOTRCombatItems.POISONED_GONDOR_DAGGER, LOTRCombatItems.POISONED_GUNDABAD_URUK_DAGGER, LOTRCombatItems.POISONED_HALF_TROLL_DAGGER,
            LOTRCombatItems.POISONED_HARADRIC_DAGGER, LOTRCombatItems.POISONED_IRON_DAGGER, LOTRCombatItems.POISONED_MITHRIL_DAGGER, LOTRCombatItems.POISONED_MORDOR_DAGGER, LOTRCombatItems.POISONED_MORWAITH_DAGGER,
            LOTRCombatItems.POISONED_RHUNIC_DAGGER, LOTRCombatItems.POISONED_ROHIRRIC_DAGGER,
            LOTRCombatItems.POISONED_TAURETHRIM_DAGGER, LOTRCombatItems.POISONED_UMBARIC_DAGGER, LOTRCombatItems.POISONED_URUK_DAGGER,
            LOTRCombatItems.POISONED_UTUMNO_DAGGER, LOTRCombatItems.RHUNIC_DAGGER,
            LOTRCombatItems.ROHIRRIC_DAGGER, LOTRCombatItems.ROLLING_PIN,
            LOTRCombatItems.SLING, LOTRCombatItems.TAURETHRIM_DAGGER, LOTRCombatItems.UMBARIC_DAGGER,
            LOTRCombatItems.URUK_DAGGER, LOTRCombatItems.UTUMNO_DAGGER, // LOTRFoodItems
            LOTRFoodItems.SHISH_KEBAB,
            // LOTRMaterialItems
            LOTRMaterialItems.BLACKROOT_STICK, LOTRMaterialItems.DWARF_BONE, LOTRMaterialItems.ELF_BONE,
            LOTRMaterialItems.HOBBIT_BONE, LOTRMaterialItems.MALLORN_STICK, LOTRMaterialItems.ORC_BONE,
            LOTRMaterialItems.TROLL_BONE, LOTRMaterialItems.WARG_BONE,
            // LOTRStoryItems
            // LOTRToolItems
            LOTRToolItems.ANGMAR_AXE, LOTRToolItems.ANGMAR_HOE, LOTRToolItems.ANGMAR_PICKAXE,
            LOTRToolItems.ANGMAR_SHOVEL, LOTRToolItems.BLUE_DWARVEN_AXE, LOTRToolItems.BLUE_DWARVEN_HOE,
            LOTRToolItems.BLUE_DWARVEN_MATTOCK, LOTRToolItems.BLUE_DWARVEN_PICKAXE, LOTRToolItems.BLUE_DWARVEN_SHOVEL,
            LOTRToolItems.BRONZE_AXE, LOTRToolItems.BRONZE_HOE, LOTRToolItems.BRONZE_PICKAXE,
            LOTRToolItems.BRONZE_SHOVEL, LOTRToolItems.CHISEL, LOTRToolItems.DOL_GULDUR_AXE,
            LOTRToolItems.DOL_GULDUR_HOE, LOTRToolItems.DOL_GULDUR_PICKAXE, LOTRToolItems.DOL_GULDUR_SHOVEL,
            LOTRToolItems.DWARVEN_AXE, LOTRToolItems.DWARVEN_HOE, LOTRToolItems.DWARVEN_MATTOCK,
            LOTRToolItems.DWARVEN_PICKAXE, LOTRToolItems.DWARVEN_SHOVEL, LOTRToolItems.GALADHRIM_AXE,
            LOTRToolItems.GALADHRIM_HOE, LOTRToolItems.GALADHRIM_PICKAXE, LOTRToolItems.GALADHRIM_SHOVEL,
            LOTRToolItems.LINDON_AXE, LOTRToolItems.LINDON_HOE, LOTRToolItems.LINDON_PICKAXE,
            LOTRToolItems.LINDON_SHOVEL, LOTRToolItems.MALLORN_AXE, LOTRToolItems.MALLORN_HOE,
            LOTRToolItems.MALLORN_PICKAXE, LOTRToolItems.MALLORN_SHOVEL, LOTRToolItems.MITHRIL_AXE,
            LOTRToolItems.MITHRIL_HOE, LOTRToolItems.MITHRIL_MATTOCK, LOTRToolItems.MITHRIL_PICKAXE,
            LOTRToolItems.MITHRIL_SHOVEL, LOTRToolItems.MOON_CHISEL, LOTRToolItems.MORDOR_AXE,
            LOTRToolItems.MORDOR_HOE, LOTRToolItems.MORDOR_PICKAXE, LOTRToolItems.MORDOR_SHOVEL,
            LOTRToolItems.RIVENDELL_AXE, LOTRToolItems.RIVENDELL_HOE, LOTRToolItems.RIVENDELL_PICKAXE,
            LOTRToolItems.RIVENDELL_SHOVEL, LOTRToolItems.SULFUR_MATCH, LOTRToolItems.TAURETHRIM_AXE,
            LOTRToolItems.TAURETHRIM_HOE, LOTRToolItems.TAURETHRIM_PICKAXE, LOTRToolItems.TAURETHRIM_SHOVEL,
            LOTRToolItems.URUK_AXE, LOTRToolItems.URUK_HOE, LOTRToolItems.URUK_PICKAXE,
            LOTRToolItems.URUK_SHOVEL, LOTRToolItems.WOOD_ELVEN_AXE, LOTRToolItems.WOOD_ELVEN_HOE,
            LOTRToolItems.WOOD_ELVEN_PICKAXE, LOTRToolItems.WOOD_ELVEN_SHOVEL);

    private LOTRFlatItemModels() {
    }

    static void generate(ItemModelGenerators generators) {
        FLAT.forEach(item -> generators.generateFlatItem(item, ModelTemplates.FLAT_ITEM));
        // The rugs (LOTRItemRugBase's icons, lionRug_lion and so on).
        for (Item rug : List.of(LOTRItems.LION_RUG, LOTRItems.LIONESS_RUG, LOTRItems.LIGHT_BEAR_RUG,
                LOTRItems.DARK_BEAR_RUG, LOTRItems.BLACK_BEAR_RUG, LOTRItems.GIRAFFE_RUG,
                LOTRItems.BROWN_WARGSKIN_RUG, LOTRItems.GREY_WARGSKIN_RUG, LOTRItems.BLACK_WARGSKIN_RUG, LOTRItems.WHITE_WARGSKIN_RUG,
                LOTRItems.ICE_WARGSKIN_RUG, LOTRItems.OBSIDIAN_WARGSKIN_RUG, LOTRItems.FIRE_WARGSKIN_RUG)) {
            generators.generateFlatItem(rug, ModelTemplates.FLAT_ITEM);
        }
        HANDHELD.forEach(item -> generators.generateFlatItem(item, ModelTemplates.FLAT_HANDHELD_ITEM));
        // The plates: flat icons, but nothing in the head slot, where LOTRPlateHeadRenderer
        // draws the plate itself (vanilla would draw the icon on the head as well).
        for (Item plate : List.of(LOTRFoodBlocks.FINE_PLATE.asItem(), LOTRFoodBlocks.WOODEN_PLATE.asItem(),
                LOTRFoodBlocks.STONEWARE_PLATE.asItem())) {
            generators.itemModelOutput.accept(plate, ItemModelUtils.select(new DisplayContext(),
                    ItemModelUtils.plainModel(generators.createFlatItemModel(plate, ModelTemplates.FLAT_ITEM)),
                    ItemModelUtils.when(ItemDisplayContext.HEAD, new EmptyModel.Unbaked())));
        }
    }
}
