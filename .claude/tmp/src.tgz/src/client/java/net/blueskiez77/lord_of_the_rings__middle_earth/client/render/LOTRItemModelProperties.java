package net.blueskiez77.lord_of_the_rings__middle_earth.client.render;

import com.mojang.serialization.MapCodec;

import net.blueskiez77.lord_of_the_rings__middle_earth.LOTRMod;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.item.LOTRStructureSpawnerItem;
import net.blueskiez77.lord_of_the_rings__middle_earth.common.world.structure.LOTRStructures;

import net.minecraft.client.color.item.ItemTintSource;
import net.minecraft.client.color.item.ItemTintSources;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperties;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperty;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

import org.jspecify.annotations.Nullable;

/**
 * The item model conditions LOTRRenderLargeItem needed and 26.2 lacks.
 *
 * <p>The original posed a pike differently by what its holder was doing: braced
 * low while sneaking, carried at a slant otherwise, and neither mid-swing so
 * the swing itself reads normally. An items/*.json can only ask about the
 * holder through a registered condition, and vanilla has none for sneaking or
 * swinging, so these two add them as {@code lotr:sneaking} and
 * {@code lotr:swinging}. ConditionalItemModelProperties.ID_MAPPER is widened to
 * public by Fabric's transitive access wideners. The structure spawner adds
 * {@code lotr:village_structure} and its tint {@code lotr:structure_spawner}
 * (ItemTintSources.ID_MAPPER widened by the mod's own), and the pouch
 * {@code lotr:pouch_open}.
 */
public final class LOTRItemModelProperties {

    private LOTRItemModelProperties() {
    }

    /** Must run before the first resource reload, which is when models parse. */
    public static void init() {
        ConditionalItemModelProperties.ID_MAPPER.put(
                Identifier.fromNamespaceAndPath(LOTRMod.NAMESPACE, "sneaking"), Sneaking.MAP_CODEC);
        ConditionalItemModelProperties.ID_MAPPER.put(
                Identifier.fromNamespaceAndPath(LOTRMod.NAMESPACE, "swinging"), Swinging.MAP_CODEC);
        ConditionalItemModelProperties.ID_MAPPER.put(
                Identifier.fromNamespaceAndPath(LOTRMod.NAMESPACE, "village_structure"), VillageStructure.MAP_CODEC);
        ItemTintSources.ID_MAPPER.put(
                Identifier.fromNamespaceAndPath(LOTRMod.NAMESPACE, "structure_spawner"), StructureSpawnerTint.MAP_CODEC);
        ConditionalItemModelProperties.ID_MAPPER.put(
                Identifier.fromNamespaceAndPath(LOTRMod.NAMESPACE, "pouch_open"), PouchOpen.MAP_CODEC);
    }

    /** LOTRItemPouch.getIcon's open pouch: the one the player has open, in its window or against a chest. */
    public record PouchOpen() implements ConditionalItemModelProperty {
        public static final MapCodec<PouchOpen> MAP_CODEC = MapCodec.unit(new PouchOpen());

        @Override
        public boolean get(ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner,
                int seed, ItemDisplayContext displayContext) {
            net.minecraft.world.entity.player.Player player = net.minecraft.client.Minecraft.getInstance().player;
            if (player == null) {
                return false;
            }
            int slot = player.containerMenu instanceof net.blueskiez77.lord_of_the_rings__middle_earth.common.inventory.LOTRPouchMenu menu
                    ? menu.pouchSlot
                    : player.containerMenu instanceof net.blueskiez77.lord_of_the_rings__middle_earth.common.inventory.LOTRChestWithPouchMenu chest
                    ? chest.pouchSlot : -1;
            return slot >= 0 && player.getInventory().getItem(slot) == stack;
        }

        @Override
        public MapCodec<PouchOpen> type() {
            return MAP_CODEC;
        }
    }

    /** A structure spawner for a village, drawn with the village icon. */
    public record VillageStructure() implements ConditionalItemModelProperty {
        public static final MapCodec<VillageStructure> MAP_CODEC = MapCodec.unit(new VillageStructure());

        @Override
        public boolean get(ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner,
                int seed, ItemDisplayContext displayContext) {
            LOTRStructures.StructureInfo info = LOTRStructureSpawnerItem.getStructure(stack);
            return info != null && info.isVillage();
        }

        @Override
        public MapCodec<VillageStructure> type() {
            return MAP_CODEC;
        }
    }

    /** getColorFromItemStack: the structure's background colour, then its foreground; white for none. */
    public record StructureSpawnerTint(int layer) implements ItemTintSource {
        public static final MapCodec<StructureSpawnerTint> MAP_CODEC = com.mojang.serialization.codecs.RecordCodecBuilder
                .mapCodec(i -> i.group(com.mojang.serialization.Codec.INT.fieldOf("layer")
                        .forGetter(StructureSpawnerTint::layer)).apply(i, StructureSpawnerTint::new));

        @Override
        public int calculate(ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner) {
            LOTRStructures.StructureInfo info = LOTRStructureSpawnerItem.getStructure(stack);
            if (info == null) {
                return -1;
            }
            return 0xFF000000 | (this.layer == 0 ? info.colorBackground() : info.colorForeground());
        }

        @Override
        public MapCodec<StructureSpawnerTint> type() {
            return MAP_CODEC;
        }
    }

    /** entityliving.isSneaking(). */
    public record Sneaking() implements ConditionalItemModelProperty {
        public static final MapCodec<Sneaking> MAP_CODEC = MapCodec.unit(new Sneaking());

        @Override
        public boolean get(ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner,
                int seed, ItemDisplayContext displayContext) {
            return owner != null && owner.isShiftKeyDown();
        }

        @Override
        public MapCodec<Sneaking> type() {
            return MAP_CODEC;
        }
    }

    /** The inverse of {@code entityliving.swingProgress <= 0.0f}. */
    public record Swinging() implements ConditionalItemModelProperty {
        public static final MapCodec<Swinging> MAP_CODEC = MapCodec.unit(new Swinging());

        @Override
        public boolean get(ItemStack stack, @Nullable ClientLevel level, @Nullable LivingEntity owner,
                int seed, ItemDisplayContext displayContext) {
            return owner != null && owner.swinging;
        }

        @Override
        public MapCodec<Swinging> type() {
            return MAP_CODEC;
        }
    }
}
